# https-github.dev-julioapm-ItAcademy2023_turma19-typescript-demo_dom_fetch

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/typescript-6kc4sg)