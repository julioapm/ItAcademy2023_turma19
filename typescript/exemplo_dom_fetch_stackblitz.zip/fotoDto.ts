export interface FotoDto {
  id: number;
  albumId: number;
  title: string;
  url: string;
  thumbnailUrl: string;
}
